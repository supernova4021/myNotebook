可以在web client上直接edit job
可以在execute flow的flow parameters那里设置参数, 然后在job的command那里可以直接使用${xxx}来引用参数