package com.me.kafka;

public class KafkaProperties {
    public static final String ZK = "127.0.0.1";

    public static final String TOPIC = "hell3";

    public static final String BROKER_LIST = "127.0.0.1:9092";
}
